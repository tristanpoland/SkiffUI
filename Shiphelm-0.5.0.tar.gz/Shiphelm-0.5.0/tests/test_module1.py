import unittest

from shiphelm import helmdocker




class TestSimple(unittest.TestCase):
    helmdocker.docker.__init__
if __name__ == '__main__':
    unittest.main()
